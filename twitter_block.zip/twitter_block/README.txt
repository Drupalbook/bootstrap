It's a custom module and it's needed J7mbo/twitter-api-php library:
https://packagist.org/packages/j7mbo/twitter-api-php

Execute command to install J7mbo/twitter-api-php:
composer require j7mbo/twitter-api-php